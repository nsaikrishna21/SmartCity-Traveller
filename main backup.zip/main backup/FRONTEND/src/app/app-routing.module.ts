import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { MapsComponent } from './maps/maps.component';
import { AboutComponent } from './about/about.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthGaurdService } from './service/auth-guard.service';
import { PageComponent } from './page/page.component';

const routes: Routes = [
  {
    path: 'login',component: LoginComponent
    
  },
  {
    path: 'signup',
    component: SignupComponent
  },
  {
    path: 'app-maps',
    component: MapsComponent,canActivate:[AuthGaurdService]
  },
  {
    path:'about',
    component:AboutComponent
  },
  {
    path:'logout',
    component:LogoutComponent
  },
  {
    path:'app-page',
    component:PageComponent,canActivate:[AuthGaurdService]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
