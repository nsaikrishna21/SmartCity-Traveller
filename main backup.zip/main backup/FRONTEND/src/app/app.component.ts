import { Component, ViewChild, Injectable, AfterViewInit } from '@angular/core';
import {NavheaderComponent} from './navheader/navheader.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//@ViewChild('sidenav') public sidenav:MatSidenav;

export class AppComponent  {
  title = 'app';
  load = true;
   loadMain = false;
    remove:boolean =true;
   hide:boolean = true;
   //message:string;

   receiveMessage($event) {
     this.hide = $event
     this.remove = $event
   }
   openForm() {
    document.getElementById("myForm").style.display = "block";
  }


  closeForm() {
    document.getElementById("myForm").style.display = "none";
  }
   show:boolean=true;
   

  

constructor(){
  setTimeout(()=> {this.load = false, this.loadMain = true}, 3000)
}

  

  
}
