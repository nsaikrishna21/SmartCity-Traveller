import { Component, OnInit, Input } from '@angular/core';
import { login } from '../login';
import { AuthenticationService } from '../service/authentication.service';
import { DataserviceService } from '../dataservice.service';
import { strttrip } from '../strttrip/strttrip';

@Component({
  selector: 'app-page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.css']
})
export class PageComponent implements OnInit {
  loadComponent =false;
  loadcontact=false;
  loadabout =false;
  loadgeo =false;
  loadprofile=false;
  loadstr =false;
  loadpentrip=false;
  loadglobe = true;
  navState=true;
  loadLogin = false;
  confirmLogout = false;
  state=false;
  viewPending = false;
  public currentuser:login;  

  successMessage: string;
  errorMessage: string;
  l:strttrip;

  // @Input()
  // chosenuser:login

  constructor(private loginService:AuthenticationService,private loginserv:DataserviceService,private dataservice:DataserviceService){ 

    this.l=this.dataservice.getTrip();

    this.currentuser=this.loginserv.getOption()
    console.log('currentuser'+JSON.stringify(this.currentuser));
  }



  loadMyChildComponent() {
    this.loadComponent = true;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo =false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadglobe =false;
    this.viewPending =false;
  }
  
  loadMyProfileComponent() {
  this.loadComponent = false;
  this.loadcontact = false;
  this.loadabout = false;
  this.loadgeo =false;
  this.loadprofile=true;
  this.loadstr =false;
  this.loadpentrip=false;
  this.loadglobe =false;
  this.viewPending =false;
}
  loadMyContactComponent(){
    this.loadComponent =false;
    this.loadcontact = true;
    this.loadabout =false;
    this.loadgeo =false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadglobe =false;
    this.viewPending =false;
  }

  loadMyAboutComponent(){
    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = true;
    this.loadgeo =false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadglobe =false;
    this.viewPending =false;
  }

  loadMygeoComponent(){
    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo =true;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadglobe =false;
    this.viewPending =false;
  }

  loadMyAboutStrtTrip(){
    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo = false;
    this.loadprofile=false;
    this.loadstr =true;
    this.loadpentrip=false;
    this.loadglobe =false;
    this.viewPending =false;
  }

  loadMyAboutpendingTrip(){
    //alert("load pending trip");
    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo = false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=true;
    this.loadglobe =false; 
    this.viewPending =false;    
  }

  loadMyviewPendingTrip(){

    

    this.errorMessage = null
    this.successMessage = null
    this.dataservice.fetchTrips(this.l).then(sign => {
      this.l = sign;
      // console.log(sign);
      // console.log(this.l);
      sessionStorage.setItem('fetchTrip',JSON.stringify(sign))
      this.dataservice.setfetchTrip(JSON.parse(sessionStorage.getItem('fetchTrip')))

       return sign;
 
 }).catch(error => {
     this.errorMessage = error.message
 return null;
 })
 



    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo = false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadglobe =false;  
    this.viewPending = true;
  }

  changeState(){
    this.navState=false;
    this.loadLogin=true;
   }


  ngOnInit() {
  }

  generateAlert(){
    this.state = confirm("Confirm LOGOUT?");
    if(this.state){
      this.confirmLogout=true;
      this.navState = false;
      this.loadLogin=false;
      this.loginService.logOut();  
    }
}


}