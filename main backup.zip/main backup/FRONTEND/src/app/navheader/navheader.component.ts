import { Component, OnInit, Injectable, Output, EventEmitter } from '@angular/core';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-navheader',
  templateUrl: './navheader.component.html',
  styleUrls: ['./navheader.component.css']
})

export class NavheaderComponent implements OnInit {
  hide:boolean = true;
  // remove(){
  //   this.hide = false;
  //   console.log(this.hide);
  //   }
    sendMessage() {
      this.hide = false;
      this.messageEvent.emit(this.hide)
    }
    constructor(private loginService:AuthenticationService){ }
  
  @Output() messageEvent = new EventEmitter<boolean>();

  // get myMethodFunc() {
  //   return this.remove.bind(this);
  // }
  
  ngOnInit() {
  }

}
