import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { DataserviceService } from '../dataservice.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  forgotpassform:any;
  successMessage: string;
  errorMessage: string;
  forgetpass:any;
  flag:boolean = false;

  constructor(private fb:FormBuilder,private service:DataserviceService) { }


  
  questions:string[]=[
    'your dream destination', 'your first pet', 'your nickname',
    'your first bestfriend'
      ]

      
  ngOnInit() {
    this.forgotpassform=this.fb.group({
      phonenumber:["",Validators.required],
      securityque:["",Validators.required],
      securityans:["",[Validators.required,Validators.pattern('^[A-Za-z][A-Za-z ]*$')]] 
    })
  }

  emailsend(){
    this.errorMessage = null
    this.successMessage = null

    this.service.ForgotPass(this.forgotpassform.value).then(sign => {
           this.forgetpass=sign;
           this.flag=true;        
           
          return sign;
    
    }).catch(error => {
      this.errorMessage = error.message
      return null;
    })

  }

}
