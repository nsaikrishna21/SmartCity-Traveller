import { FormGroup } from '@angular/forms';
 
export class ConfirmPasswordValidator {
    static validate(signupform: FormGroup) {
        let password = signupform.controls.password.value;
        let repeatPassword = signupform.controls.repeatPassword.value;
 
        
        // if (repeatPassword.length <= 0) {
        //     return null;
        // }
 
        if (repeatPassword !== password) {
            console.log("not match") //COMMENT IT
            return {
                'doesMatchPassword': true
            };
            
            

        }
        else{
            console.log("match")
            
        }
        return null;
        
 
    }
}