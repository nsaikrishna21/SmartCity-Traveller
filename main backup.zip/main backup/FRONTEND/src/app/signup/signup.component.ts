import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup} from '@angular/forms';
import { PhoneNumberValidator } from './phone-number.validator';
import {ConfirmPasswordValidator} from './confirm-password.validator';
import { Signup } from './signup';
import { DataserviceService } from '../dataservice.service';
import { EncrDecrService } from '../encr-decr.service';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  successMessage: string;
  errorMessage: string;
  signupobj : Signup;

  loginflag = false;  
  signupflag=false;
  signupform:FormGroup;
  show: boolean;

  passwordFormGroup: FormGroup;
  
  // constructor(private fb:FormBuilder) { 
  //   this.show = false;
  // }

  constructor(private fb:FormBuilder,private EncrDecr: EncrDecrService, 
    private signupserv:DataserviceService) {
          this.show = false;

     }

  

  locations:string[]=[
    'Allepey', 'Kumarkom', 'Srinagar', 'Goa', 'Kochi', 'Asan Barrage',
    'Hyderabad','chennai','Erode'
  ]

  questions:string[]=[
    'your dream destination', 'your first pet', 'your nickname',
    'your first bestfriend'
      ]
      

  ngOnInit() {
    var encrypted = this.EncrDecr.set('123456$#@$^@1ERF', 'password@123456');
    var decrypted = this.EncrDecr.get('123456$#@$^@1ERF', encrypted);
   
    console.log('Encrypted :' + encrypted);
    console.log('Encrypted :' + decrypted);
    this.signupform=this.fb.group({
      // usertype:["",Validators.required],
      uname:["",[Validators.required,Validators.pattern('[\\w]+')]],
      name:["",[Validators.required,Validators.pattern('([A-Za-z]+)([\\s]*[A-Za-z]+)*')]],
      emailed:["", [Validators.required,Validators.email] ],
      phonenumber:["",[Validators.required,Validators.pattern('^[0-9]{10}$'),PhoneNumberValidator.noRepeat]],
      gender:["",Validators.required],
      dateofbirth:["",Validators.required],
      cityofbirth:["",Validators.required],
      address:["",[Validators.required,Validators.minLength(25)]],
      password:["",[Validators.required,Validators.minLength(8),Validators.pattern('^[\\w]+[@^#*]*[\\w]*$')]],
      securityque:["",Validators.required],
      securityans:["",[Validators.required,Validators.pattern('^[A-Za-z][A-Za-z ]*$')]] 
      // passwordFormGroup:this.fb.group(
      //   {
      // password:["",[Validators.required,Validators.minLength(8),Validators.pattern('^[\\w]+[@^#*]*[\\w]*$')]],
      // repeatPassword: ['', [Validators.required]]
      //   }
      //   ,{
      //     validator: ConfirmPasswordValidator.validate.bind(this)
         
      //   }
      // )
      

    // })
    // this.passwordFormGroup = this.fb.group({
    //   password:["",[Validators.required,Validators.minLength(8),Validators.pattern('^[\\w]+[@^#*]*[\\w]*$')]],
    //   repeatPassword: ['', Validators.required]
    // }, {
    //   validator: ConfirmPasswordValidator.doesMatchPassword.bind(this)
    });
  }

  onselect1():void{
  }

  password() {
    this.show = !this.show;
}


addregdetails() {
  this.errorMessage = null
  this.successMessage = null
  this.signupobj = null
  this.signupserv.addregdetails(this.signupform.value).then(sign => {
  this.signupobj = sign;
  this.signupflag= true;
  this.loginflag = true;
  

  }).catch(error => {
    this.errorMessage = error.message
  })
}


  
}
