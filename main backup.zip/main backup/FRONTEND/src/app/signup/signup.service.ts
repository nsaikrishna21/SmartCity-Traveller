import { Injectable } from '@angular/core';
import{Http} from '@angular/http';
import { Signup } from './signup';
@Injectable({
  providedIn: 'root'
})
export class SignupService {

  constructor(private http:Http) { }

  addregdetails(data) : Promise<Signup> {
    return this.http.post('http://localhost:8765/SmartCityTraveller/SmartApi/setReg', data)
    .toPromise()
    .then(response => response.json())
    .catch(this.errorHandler)
  }

  errorHandler(error){
    return Promise.reject(error.json())
  }
}
