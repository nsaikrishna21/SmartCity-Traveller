import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { login } from './login';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http:Http) { }

  UserLogin(data) : Promise<login> {
    return this.http.post('http://localhost:8765/SmartCityTraveller/SmartApi/login', data)
    .toPromise()
    .then(response => response.json())
    .catch(this.errorHandler)
  }
  
  errorHandler(error){
    return Promise.reject(error.json())
  }


}
