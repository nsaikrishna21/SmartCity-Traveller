import { Component, OnInit, Input ,EventEmitter ,Output } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

import { DataserviceService } from '../dataservice.service';
import { login } from '../login';
import { AuthenticationService } from '../service/authentication.service';
// import { LoginService } from './login.service';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username = 'javainuse'
  passwd = ''
  invalidLogin = false

  successMessage: string;
  errorMessage: string;
  loginObj : login;
  loginobject:login;

  @Input()
  userFromforget:login;
  disableflag:boolean = false;



  constructor(private fb:FormBuilder, private loginserv:DataserviceService,private router: Router,
    private loginservice: AuthenticationService) { }
  loginform:any;
  remove:boolean = true;
  @Output() messageEvent = new EventEmitter<boolean>();
  

  ngOnInit() {
    if(this.userFromforget == null){
    this.loginform=this.fb.group({
      // username:["",null],
      phonenumber:["",null],
      password:["",null]
    })
   }
   else{
    this.disableflag=true;
    this.loginform=this.fb.group({
      // username:["",null],
      phonenumber:[this.userFromforget.phonenumber,null],
      password:[this.userFromforget.password,null]
    })
   }

  } 
  forgotpasss=false;
  loginflag = false;  
  signupflag = false; 
  pageflag = true;
  show =false;
  // @Input()
  // navshow:Function;
  //@Output() outputTOparent = new EventEmitter<boolean>();
 ob = new login();

  get f() { return this.loginform.controls }

onselect():void{
    //this.outputTOparent.emit(this.show)
    // this.navshow();
    // this.remove =false;
    // this.messageEvent.emit(this.remove)
    // this.loginflag = true;
    // this.signupflag = true;
    // this.pageflag=false;
}


forgotpass(){
  this.forgotpasss=true;
  this.loginflag = true;
  }

password() {
  this.show = !this.show;
}


UserLogin() {
  this.errorMessage = null
  this.successMessage = null
  this.loginObj = null
  this.loginserv.UserLogin(this.loginform.value).then(sign => {
  this.loginObj = sign;
  

  sessionStorage.setItem('username', this.f.phonenumber.value)
  sessionStorage.setItem('updateObj',JSON.stringify(this.loginObj))

  //this.loginobject = sessionStorage.getItem
  //console.log("1"+);
  //console.log("2"+JSON.stringify(this.f.uname));

  this.loginserv.setOption(JSON.parse(sessionStorage.getItem('updateObj')))



  this.loginobject = JSON.parse(sessionStorage.getItem('updateObj'));
  this.remove =false;
  this.messageEvent.emit(this.remove)
  this.loginflag = true;
  this.signupflag = true;
  this.pageflag=false;
  this.invalidLogin = false
  this.router.navigate(['app-page'])

  return sign;
  
  }).catch(error => {
    this.errorMessage = error.message
    this.invalidLogin = true
    return null;
  })


}

// checkLogin() {
//   if (this.loginservice.authenticate(this.f.phonenumber.value, this.f.password.value)
//   ) {
//     this.router.navigate(['app-maps'])
//     this.invalidLogin = false
//   } else
//     this.invalidLogin = true
// }

}
