import { Component, OnInit } from '@angular/core';
import {  Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { PhoneNumberValidator } from '../signup/phone-number.validator';
import { formControlBinding } from '@angular/forms/src/directives/ng_model';
import { profile } from './profile';
import { DataserviceService } from '../dataservice.service';
import { login } from '../login';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  // @Input()
  // choseuser:login;
  signupform: FormGroup;
  successMessage: string;
  errorMessage: string;
  profileObj:profile;
  l:login;


  private dataserv : DataserviceService;

  constructor(private fb:FormBuilder,  private profileServ:DataserviceService, private loginserv:DataserviceService) {
   
    this.l=this.loginserv.getOption();

  //   sessionStorage.setItem('newobj',JSON.stringify(this.l))
  //  this.l =JSON.parse(sessionStorage.getItem('newobj'))
   }

  ngOnInit() {

    this.signupform=this.fb.group({
      // uname:[this.choseuser.uname,[Validators.pattern('[\\w]+')]],
      // name:[this.choseuser.name,[Validators.pattern('([A-Za-z]+)([\\s]*[A-Za-z]+)*')]],
      // emailed:[this.choseuser.emailed, [Validators.email] ],
      // phonenumber:[this.choseuser.phonenumber,[Validators.pattern('^[0-9]{10}$'),PhoneNumberValidator.noRepeat]],
      // gender:[this.choseuser.gender],
      // dateofbirth:[this.choseuser.dateofbirth],
      // address:[this.choseuser.address,[Validators.minLength(25)]],
      // cityofbirth:[this.choseuser.cityofbirth,[Validators.required]],

      uname:[this.l.uname,[Validators.pattern('[\\w]+')]],
      name:[this.l.name,[Validators.pattern('([A-Za-z]+)([\\s]*[A-Za-z]+)*')]],
      emailed:[this.l.emailed, [Validators.email] ],
      phonenumber:[this.l.phonenumber,[Validators.pattern('^[0-9]{10}$'),PhoneNumberValidator.noRepeat]],
      gender:[this.l.gender],
      dateofbirth:[this.l.dateofbirth],
      address:[this.l.address,[Validators.minLength(25)]],
      cityofbirth:[this.l.cityofbirth,[Validators.required]],
    })
  }

  updation(){
    console.log("Inside updation")
    this.errorMessage = null
    this.successMessage = null
    this.profileObj = null
    console.log("before service call")
    this.profileServ.updation(this.signupform.value).then(sign => {
      this.successMessage = "YOUR DETAILS WERE SUCCESSFULLY UPDATED!";
      this.profileObj = sign;
    console.log(this.successMessage)
    }).catch(error => {
      console.log("In catch")
      this.errorMessage = "ERROR IN UPDATING YOUR DETAILS!"
      console.log(this.errorMessage)
    })
  
  
   
  }
  

}
