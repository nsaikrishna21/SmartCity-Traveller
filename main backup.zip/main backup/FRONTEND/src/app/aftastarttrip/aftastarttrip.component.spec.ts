import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AftastarttripComponent } from './aftastarttrip.component';

describe('AftastarttripComponent', () => {
  let component: AftastarttripComponent;
  let fixture: ComponentFixture<AftastarttripComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AftastarttripComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AftastarttripComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
