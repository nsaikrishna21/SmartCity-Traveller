import { Component, OnInit } from '@angular/core';
import { DataserviceService } from '../dataservice.service';
import { strttrip } from '../strttrip/strttrip';

@Component({
  selector: 'app-viewpendingtrips',
  templateUrl: './viewpendingtrips.component.html',
  styleUrls: ['./viewpendingtrips.component.css']
})
export class ViewpendingtripsComponent implements OnInit {
l:any;
listTrip:strttrip[];
i:strttrip;
  constructor(private service:DataserviceService) { 

    this.l=this.service.getfetchTrip();
    console.log("----full---")
    console.log(this.l);

    

  }

  ngOnInit() {
  }

}
