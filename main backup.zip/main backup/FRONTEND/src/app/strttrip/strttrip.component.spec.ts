import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StrttripComponent } from './strttrip.component';

describe('StrttripComponent', () => {
  let component: StrttripComponent;
  let fixture: ComponentFixture<StrttripComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StrttripComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StrttripComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
