import { Component, OnInit } from '@angular/core';
import { login } from '../login';
import { DataserviceService } from '../dataservice.service';
import { strttrip } from './strttrip';

@Component({
  selector: 'app-strttrip',
  templateUrl: './strttrip.component.html',
  styleUrls: ['./strttrip.component.css']
})
export class StrttripComponent implements OnInit {
  loadpentrip=false;
  starttrip=true;
  Strip:any;
  Etrip:any;
  
  tripObj : strttrip;
  l:login;
  constructor(private Tripserv:DataserviceService) { 
    this.l=this.Tripserv.getOption();
  }

  ngOnInit() {
    
  }
  public selectedMoments = [
    new Date(),
    new Date()
];
pendingtrip(){
  // alert("hello");
  this.Strip=this.selectedMoments[0];
  this.Etrip=this.selectedMoments[1];
  
  this.tripObj = new strttrip();

  this.tripObj.setRid(this.l.rid);
  this.tripObj.setStart(this.Strip);
  this.tripObj.setEnd(this.Etrip);
  this.tripObj.setStatus("PENDING");
  //console.log(this.Strip)
  //console.log(this.Etrip)

  sessionStorage.setItem('tripOb',JSON.stringify(this.tripObj))
  this.Tripserv.setTrip(JSON.parse(sessionStorage.getItem('tripOb')))


  this.loadpentrip=true;
  this.starttrip=false;
  // this.router.navigate(['app-pendingtrip'])
}

}
