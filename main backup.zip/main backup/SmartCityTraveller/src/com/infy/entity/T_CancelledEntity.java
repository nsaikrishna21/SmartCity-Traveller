package com.infy.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="T_Cancelled")
public class T_CancelledEntity {
	
	@Id
	private Integer CanId;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "TId", unique = true)
	private TripsEntity TId;
	private LocalDateTime CancelTime; 
	private String Feedback; 

	public TripsEntity getTId() {
		return TId;
	}
	public void setTId(TripsEntity tId) {
		TId = tId;
	}
	public Integer getCanId() {
		return CanId;
	}
	public void setCanId(Integer canId) {
		CanId = canId;
	}
	public LocalDateTime getCancelTime() {
		return CancelTime;
	}
	public void setCancelTime(LocalDateTime cancelTime) {
		CancelTime = cancelTime;
	}
	public String getFeedback() {
		return Feedback;
	}
	public void setFeedback(String feedback) {
		Feedback = feedback;
	}
	
}
