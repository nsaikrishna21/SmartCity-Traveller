package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Question")
public class QuestionEntity {
	@Id
	private Integer QId;
	private String Que;
	public Integer getQId() {
		return QId;
	}
	public void setQId(Integer qId) {
		QId = qId;
	}
	public String getQue() {
		return Que;
	}
	public void setQue(String que) {
		Que = que;
	}
	

}
