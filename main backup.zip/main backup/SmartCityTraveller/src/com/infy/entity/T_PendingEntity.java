package com.infy.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="T_Pending")
public class T_PendingEntity {
	@Id
	private Integer PId;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="TId",unique=true)
	private TripsEntity TId;
	public Integer getPId() {
		return PId;
	}
	public void setPId(Integer pId) {
		PId = pId;
	}
	public TripsEntity getTId() {
		return TId;
	}
	public void setTId(TripsEntity tId) {
		TId = tId;
	}
	
	

}
