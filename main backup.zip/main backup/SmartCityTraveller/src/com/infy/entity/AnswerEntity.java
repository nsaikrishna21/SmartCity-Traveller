package com.infy.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Answer")
public class AnswerEntity {
	@Id
	private Integer AId; 
	private String Answer;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="QId", unique=true)
	private QuestionEntity question;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="RId")
	private RegisterDetailsEntity RId;
	
	public Integer getAId() {
		return AId;
	}
	public RegisterDetailsEntity getRId() {
		return RId;
	}
	public void setRId(RegisterDetailsEntity rId) {
		RId = rId;
	}
	public void setAId(Integer aId) {
		AId = aId;
	}
	public String getAnswer() {
		return Answer;
	}
	public void setAnswer(String answer) {
		Answer = answer;
	}
	
	public QuestionEntity getQuestion() {
		return question;
	}
	public void setQuestion(QuestionEntity question) {
		this.question = question;
	}

}
