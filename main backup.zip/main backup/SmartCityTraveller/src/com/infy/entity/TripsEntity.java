package com.infy.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name ="Trips")
@GenericGenerator(name="pkgen",strategy="increment")
public class TripsEntity{
	@Id
	@GeneratedValue(generator="pkgen")
	private Integer TId;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="RId")
	private RegisterDetailsEntity RId;
	private LocalDateTime StartTime;
	private LocalDateTime EndTime;
	private TripStatus Status;
	
	public RegisterDetailsEntity getRId() {
		return RId;
	}
	public void setRId(RegisterDetailsEntity rId) {
		RId = rId;
	}

	public Integer getTId() {
		return TId;
	}
	public void setTId(Integer tId) {
		TId = tId;
	}
	public LocalDateTime getStartTime() {
		return StartTime;
	}
	public void setStartTime(LocalDateTime startTime) {
		StartTime = startTime;
	}
	public LocalDateTime getEndTime() {
		return EndTime;
	}
	public void setEndTime(LocalDateTime endTime) {
		EndTime = endTime;
	}
	public TripStatus getStatus() {
		return Status;
	}
	public void setStatus(TripStatus status) {
		Status = status;
	} 

}



