DROP TABLE RegisterDetails;
DROP TABLE Question;
DROP TABLE Answer;
DROP TABLE Trips;
DROP TABLE T_Completed;
DROP TABLE T_Cancelled;
DROP TABLE T_Pending;


create table RegisterDetails (
RId number(12) PRIMARY KEY,
uname varchar2(30) not null,
password varchar2(30) not null,
name varchar(50) not null,
address varchar2(50) not null,
phonenumber varchar2(10) not null,
emailed varchar2(50) not null,
cityofbirth varchar2(50) not null,
dateofbirth date not null,
gender varchar2(30) not null,
securityque varchar2(30) not null,
securityans varchar2(30) not null
);

select * from RegisterDetails;
INSERT INTO RegisterDetails VALUES(12345,'SAMI','PASS','SAMILA','SAFFF0',1234567890,'SDLKHA','KERALA','12-Jan-1993','ADMIN');
INSERT INTO RegisterDetails VALUES(12365,'SAMI','PASS','SAMILA','SAFFF0',1234567890,'SDLKHA','KERALA','12-Jan-1993','NORMAL');





CREATE TABLE Question(
QId number(10) primary key,
Que varchar2(100) not null
);

INSERT INTO Question VALUES (123,'askhalshd');



CREATE TABLE Answer(
AId number(10) primary key,
Answer varchar2(100) not null,
QId number(10) references Question(QId),
RId number(12) references RegisterDetails(RId)
);


CREATE TABLE Trips(
TId number(15) primary key,
RId number(12) references RegisterDetails(RId),
StartTime TIMESTAMP not null,
EndTime TIMESTAMP not null,
Status varchar2(20),
CONSTRAINT chk_status CHECK (Status in ('COMPLETED','CANCELLED','PENDING'))
);

CREATE TABLE T_Completed(
CId number(15) primary key,
TId number(15) references Trips(TId),
Feedback varchar2(100) not null
);

CREATE TABLE T_Cancelled(
CanId number(15) primary key,
TId number(15) references Trips(TId),
CancelTime TIMESTAMP not null,
Feedback varchar2(100) not null
);


CREATE TABLE T_Pending(
PId number(15) primary key,
TId number(15) references Trips(TId)
);



select * from RegisterDetails;
select * from Question;
