package com.infy.dao;


import java.util.List;


import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.RegisterDetailsEntity;


import com.infy.model.RegisterDetails;


@Repository("dao")
public class UDAIDAOImpl implements UDAIDAO {

	@Autowired
	SessionFactory sessionFactory;


	/*@Override
	public AadharCard updatePhoneNumber(AadharCard aadhar) {
		Session session = sessionFactory.getCurrentSession();
		AadharCardEntity aadharCardEntity = session.get(AadharCardEntity.class, aadhar.getAadharNumber());
		if(	aadharCardEntity !=null) {
			aadharCardEntity.setPhoneNumber(aadhar.getPhoneNumber());
			return aadhar;
		}
		return null;
	}*/

//	@Override
//	public Login getLoginDetails(Integer RId) {
//		// TODO Auto-generated method stub
//		
//		Session session = sessionFactory.getCurrentSession();
//		RegisterDetailsEntity registerdetailsentity = session.get(RegisterDetailsEntity.class, RId);
//		
//		if(	registerdetailsentity !=null) {
//			Login user = new Login();		
//			user.setUname(registerdetailsentity.getUname());
//			user.setPassword(registerdetailsentity.getPassword());
//			return user;
//		
//		}
//		return null;
//		
//	}

	@Override
	public RegisterDetails add(RegisterDetails cust) {
		// TODO Auto-generated method stub

		Session session=sessionFactory.getCurrentSession();
		
		System.out.println(cust.getRId());
		System.out.println(cust.getAddress());
		System.out.println(cust.getCityofbirth());
		System.out.println(cust.getName());
		System.out.println(cust.getUname());
	    System.out.println(cust.getEmailed());
		System.out.println(cust.getPassword());
		System.out.println(cust.getPhonenumber());
		System.out.println(cust.getGender());
		
		RegisterDetailsEntity cde=session.get(RegisterDetailsEntity.class,cust.getRId());
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<RegisterDetailsEntity> cq=builder.createQuery(RegisterDetailsEntity.class);
		Root<RegisterDetailsEntity> root=cq.from(RegisterDetailsEntity.class);
		cq.select(root);
		cq.where(builder.or(builder.like(root.get("phonenumber"),cust.getPhonenumber()),builder.like(root.get("uname"),cust.getUname()) ) );
		
		List<RegisterDetailsEntity> customerEntityList = session.createQuery(cq).list();
		
		if(!(customerEntityList.isEmpty())){
			return null;
		}	
		if(cde != null   ){return null;}
		 
		else{
			ENCRYPT m;
			m = new ENCRYPT(cust.getPassword());
			String password = m.toString();
			
			
			RegisterDetailsEntity cd=new RegisterDetailsEntity();
			cd.setAddress(cust.getAddress());
            cd.setCityofbirth(cust.getCityofbirth());
            cd.setDateofbirth(cust.getDateofbirth());
            cd.setEmailed(cust.getEmailed());
            cd.setName(cust.getName());
            cd.setPassword(password);
            cd.setPhonenumber(cust.getPhonenumber());
            cd.setRId(cust.getRId());
            cd.setGender(cust.getGender());
            cd.setUname(cust.getUname());
            cd.setSecurityque(cust.getSecurityque());
            cd.setSecurityans(cust.getSecurityans());
			session.save(cd);
			return cust;
		}
		
	}
	
	
	
	
	public RegisterDetails login(String phoneORuname, String password) {
		// TODO Auto-generated method stub
///		System.out.println("in dao");
		Session session=sessionFactory.getCurrentSession();
		String phoneORuser=phoneORuname;
	
		
		ENCRYPT m;
        m = new ENCRYPT(password);
		
		String pass = m.toString();
		
		System.out.println("------------------------------------------------------");
	    System.out.println("password is : "+pass);
	    System.out.println("------------------------------------------------------");
	    
	    
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<RegisterDetailsEntity> cq=builder.createQuery(RegisterDetailsEntity.class);
		Root<RegisterDetailsEntity> root=cq.from(RegisterDetailsEntity.class);
		cq.select(root);
		
/*		System.out.println("passed.pass : "+ pass);
		System.out.println("passed.phone : "+ phoneORuname);
		

		System.out.println("root.pass : "+ root.get("password"));
		System.out.println("root.phone : "+ root.get("phonenumber"));*/
		
		cq.where(builder.or (  builder.and(
				builder.equal(root.get("uname"),phoneORuser),
				builder.equal(root.get("password"),pass)),
				 builder.and(
							builder.equal(root.get("phonenumber"),phoneORuser),
							builder.equal(root.get("password"),pass))
				 ));
		
		List<RegisterDetailsEntity> customerEntityList = session.createQuery(cq).list();
		
	
		
		if(!customerEntityList.isEmpty()) {
			
			RegisterDetails obj = new RegisterDetails();
			RegisterDetailsEntity userDetail = session.get(RegisterDetailsEntity.class,customerEntityList.get(0).getRId());
			
			DECRYPT d = new DECRYPT(userDetail.getPassword());
			pass = d.toString();
			
			obj.setAddress(userDetail.getAddress());
			obj.setCityofbirth(userDetail.getCityofbirth());
			obj.setDateofbirth(userDetail.getDateofbirth());
			obj.setEmailed(userDetail.getEmailed());
			obj.setName(userDetail.getName());
			obj.setPassword(pass);
			obj.setPhonenumber(userDetail.getPhonenumber());
			obj.setRId(userDetail.getRId());
			obj.setUname(userDetail.getUname());
			obj.setGender(userDetail.getGender());
			
			return obj;
		}
		
		else{

			return null;
		}

		}




	@Override
	public RegisterDetails update(RegisterDetails user) {
		// TODO Auto-generated method stub
		String username = user.getUname();
		
		System.out.println(user.getRId());
		System.out.println(user.getAddress());
		System.out.println(user.getCityofbirth());
		System.out.println(user.getName());
		System.out.println(user.getUname());
	    System.out.println(user.getEmailed());
		System.out.println(user.getPassword());
		System.out.println(user.getPhonenumber());
		System.out.println(user.getGender());
		
		Session session=sessionFactory.getCurrentSession();
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<RegisterDetailsEntity> cq=builder.createQuery(RegisterDetailsEntity.class);
		Root<RegisterDetailsEntity> root=cq.from(RegisterDetailsEntity.class);
		cq.select(root);
		
		cq.where(builder.equal(root.get("uname"),username));
		
		List<RegisterDetailsEntity> customerEntityList = session.createQuery(cq).list();
		
	if(!customerEntityList.isEmpty()) {
			

		
			RegisterDetailsEntity userDetail = session.get(RegisterDetailsEntity.class,customerEntityList.get(0).getRId());
			
		
			user.setRId(userDetail.getRId());
			
			userDetail.setAddress(user.getAddress());
			userDetail.setDateofbirth(user.getDateofbirth());
			userDetail.setCityofbirth(user.getCityofbirth());
			userDetail.setEmailed(user.getEmailed());
			userDetail.setName(user.getName());
			userDetail.setPassword(userDetail.getPassword());
			userDetail.setPhonenumber(user.getPhonenumber());
			userDetail.setUname(user.getUname());
			userDetail.setGender(user.getGender());
			
		
			user.setAddress(userDetail.getAddress());
			user.setCityofbirth(userDetail.getCityofbirth());
			user.setDateofbirth(userDetail.getDateofbirth());
			user.setEmailed(userDetail.getEmailed());
			user.setName(userDetail.getName());
			user.setPassword(userDetail.getPassword());
			user.setPhonenumber(userDetail.getPhonenumber());
			user.setUname(userDetail.getUname());
			user.setGender(userDetail.getGender());
			
			System.out.println("----------------ENTITY--------------");
			System.out.println(userDetail.getRId());
			System.out.println(userDetail.getAddress());
			System.out.println(userDetail.getCityofbirth());
			System.out.println(userDetail.getName());
			System.out.println(userDetail.getUname());
		    System.out.println(userDetail.getEmailed());
			System.out.println(userDetail.getPassword());
			System.out.println(userDetail.getPhonenumber());
			System.out.println(userDetail.getGender());
		
			
			
			return user;
		}
	
	
	else {
		return null;
	}
		
		
	}




	@Override
	public RegisterDetails forgotpassword(String phonenumber, String securityque, String securityans) {
		// TODO Auto-generated method stub
		///		System.out.println("in dao");
				Session session=sessionFactory.getCurrentSession();
				String ph=phonenumber;
			    String que = securityque;
			    String ans = securityans;
			    
				CriteriaBuilder builder=session.getCriteriaBuilder();
				CriteriaQuery<RegisterDetailsEntity> cq=builder.createQuery(RegisterDetailsEntity.class);
				Root<RegisterDetailsEntity> root=cq.from(RegisterDetailsEntity.class);
				cq.select(root);
				
				cq.where(builder.and(
						(builder.equal(root.get("phonenumber"),ph)),
						(builder.equal(root.get("securityque"), que)),
						(builder.equal(root.get("securityans"), ans))
						));
			
				
				List<RegisterDetailsEntity> customerEntityList = session.createQuery(cq).list();
				
			
				
				if(!customerEntityList.isEmpty()) {

					
					
					RegisterDetails obj = new RegisterDetails();
					RegisterDetailsEntity userDetail = session.get(RegisterDetailsEntity.class,customerEntityList.get(0).getRId());
					DECRYPT d = new DECRYPT(userDetail.getPassword());
					String pass = d.toString();
					
					obj.setAddress(userDetail.getAddress());
					obj.setCityofbirth(userDetail.getCityofbirth());
					obj.setDateofbirth(userDetail.getDateofbirth());
					obj.setEmailed(userDetail.getEmailed());
					obj.setName(userDetail.getName());
					obj.setPassword(pass);
					obj.setPhonenumber(userDetail.getPhonenumber());
					obj.setRId(userDetail.getRId());
					obj.setUname(userDetail.getUname());
					obj.setGender(userDetail.getGender());
					obj.setSecurityque(userDetail.getSecurityque());
					obj.setSecurityans(userDetail.getSecurityans());
					
					return obj;
				}
				
				else{

					return null;
				}
	}


	
	
	
	
	
	
	
}
