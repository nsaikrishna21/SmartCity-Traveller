package com.infy.dao;


import java.security.SecureRandom;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

class ENCRYPT {
	byte[] skey = new byte[1000];
	String skeyString;
	static byte[] raw;
	String inputMessage,encryptedData,decryptedMessage;
	String messageToreturn;
	

	public ENCRYPT(String password) {
		try {
			
			generateSymmetricKey();

			inputMessage = password;
			byte[] ibyte = inputMessage.getBytes();
			

byte[] ebyte=encrypt(raw, ibyte);
String encryptedData = new String(ebyte);
messageToreturn = encryptedData;
System.out.println("Encrypted message :"+encryptedData);
	}
		
		catch(Exception e) {
			System.out.println(e);
			}
		
	
}
	

	void generateSymmetricKey() {
		try {
		Random r = new Random();
//		int num = r.nextInt(10000);
		int num = 1000;
		String knum = String.valueOf(num);
		byte[] knumb = knum.getBytes();
		skey=getRawKey(knumb);
		skeyString = new String(skey);
		//System.out.println("AES Symmetric key = "+skeyString);
		}
		catch(Exception e) {
		System.out.println(e);
		}
		}
	
	
	private static byte[] getRawKey(byte[] seed) throws Exception {
		KeyGenerator kgen = KeyGenerator.getInstance("AES");
		SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
		sr.setSeed(seed);
		kgen.init(128, sr);
		SecretKey skey = kgen.generateKey();
		raw = skey.getEncoded();
		return raw;
		}
	
	
	private static byte[] encrypt(byte[] raw, byte[] clear) throws Exception {
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		byte[] encrypted = cipher.doFinal(clear);
		return encrypted;
		}
	
	

    @Override
    public String toString() { 
        return messageToreturn; 
    } 
	
	
}
	

	

