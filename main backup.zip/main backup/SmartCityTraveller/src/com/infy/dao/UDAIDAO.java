package com.infy.dao;



import com.infy.entity.RegisterDetailsEntity;
import com.infy.model.RegisterDetails;

public interface UDAIDAO {
	
	//public Login getLoginDetails(Integer RId);
	public RegisterDetails add(RegisterDetails addUser);
	public RegisterDetails login(String phoneORuname, String password);
	public RegisterDetails update(RegisterDetails user);
	public RegisterDetails forgotpassword(String phonenumber, String securityque, String securityans);
	
	//public AadharCard updatePhoneNumber(AadharCard aadhar);
	
}
