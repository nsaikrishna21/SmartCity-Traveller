package com.infy.model;





public class Answer {
	private Integer AId; 
	private String Answer;
	private Question question;
	private RegisterDetails RId;
	
	public Integer getAId() {
		return AId;
	}
	public void setAId(Integer aId) {
		AId = aId;
	}
	public String getAnswer() {
		return Answer;
	}
	public void setAnswer(String answer) {
		Answer = answer;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public RegisterDetails getRId() {
		return RId;
	}
	public void setRId(RegisterDetails rId) {
		RId = rId;
	}
	

}
