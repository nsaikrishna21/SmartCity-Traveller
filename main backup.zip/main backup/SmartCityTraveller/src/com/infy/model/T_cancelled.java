package com.infy.model;

import java.time.LocalDateTime;



public class T_cancelled {

	private Integer CanId;
	private Trips TId;
	private LocalDateTime CancelTime; 
	private String Feedback; 

	
	public Integer getCanId() {
		return CanId;
	}
	public void setCanId(Integer canId) {
		CanId = canId;
	}
	public Trips getTId() {
		return TId;
	}
	public void setTId(Trips tId) {
		TId = tId;
	}
	public LocalDateTime getCancelTime() {
		return CancelTime;
	}
	public void setCancelTime(LocalDateTime cancelTime) {
		CancelTime = cancelTime;
	}
	public String getFeedback() {
		return Feedback;
	}
	public void setFeedback(String feedback) {
		Feedback = feedback;
	}
	
}
