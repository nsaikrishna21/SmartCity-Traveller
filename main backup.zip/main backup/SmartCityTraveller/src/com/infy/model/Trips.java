package com.infy.model;

import java.time.LocalDateTime;

public class Trips {
private Integer TId;
private RegisterDetails RId;
private LocalDateTime StartTime;
private LocalDateTime EndTime;
private TripStatus Status;


public LocalDateTime getStartTime() {
	return StartTime;
}
public void setStartTime(LocalDateTime startTime) {
	StartTime = startTime;
}
public LocalDateTime getEndTime() {
	return EndTime;
}
public void setEndTime(LocalDateTime endTime) {
	EndTime = endTime;
}
public TripStatus getStatus() {
	return Status;
}
public void setStatus(TripStatus status) {
	Status = status;
}
public Integer getTId() {
	return TId;
}
public void setTId(Integer tId) {
	TId = tId;
}
public RegisterDetails getRId() {
	return RId;
}
public void setRId(RegisterDetails rId) {
	RId = rId;
}
	
}


enum TripStatus{
	COMPLETED, CANCELLED, PENDING;
}

