package com.infy.api;


import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.RegisterDetails;
import com.infy.service.UDAIService;
import com.infy.service.UDAIServiceImpl;
import com.infy.utility.ContextFactory;



@RestController
@CrossOrigin
@RequestMapping(value="SmartApi")
public class UDAIApi {
	
	private UDAIService service;
	private int id = 1000;
	@RequestMapping(method=RequestMethod.POST, value="setReg")
	public ResponseEntity<RegisterDetails> setReg(@RequestBody RegisterDetails user){

		
		
		System.out.println("-------------------------------------------------------");
		System.out.println(user.getRId());
		System.out.println(user.getAddress());
		System.out.println(user.getCityofbirth());
		System.out.println(user.getName());
		System.out.println(user.getUname());
	    System.out.println(user.getEmailed());
		System.out.println(user.getPassword());
		System.out.println(user.getPhonenumber());
		System.out.println(user.getGender());
		System.out.println(user.getSecurityans());
		System.out.println(user.getSecurityque());
		System.out.println("-------------------------------------------------------");
		
		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service = (UDAIService) ContextFactory.getContext().getBean(UDAIServiceImpl.class);
		
		ResponseEntity<RegisterDetails> responseEntity;
		try {
		//	user.setPassword("pass");
		    id += 1;
			user.setRId(id);
			
			RegisterDetails cd = service.add(user);
			cd.setMessage(environment.getProperty("RegisterAPI.SUCCESS"));
			responseEntity = new ResponseEntity<RegisterDetails>(cd,HttpStatus.OK);

		}

		catch(Exception exception) {
			String errorMessage = environment.getProperty(exception.getMessage());
			RegisterDetails fb = new RegisterDetails();
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<RegisterDetails>(fb,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;

	}
	

	
	@RequestMapping(method=RequestMethod.POST, value="login")
    public ResponseEntity<RegisterDetails> login(@RequestBody RegisterDetails log) {
	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (UDAIService) ContextFactory.getContext().getBean(UDAIServiceImpl.class);
	
	ResponseEntity<RegisterDetails> responseEntity;
	try{
		System.out.println("IN try");
		RegisterDetails bs=service.login(log.getPhonenumber(),log.getPassword());
		bs.setMessage(environment.getProperty("UDAIApi.LOGINSUCCESSFULL"));
		responseEntity = new ResponseEntity<RegisterDetails>(bs,HttpStatus.OK);
		
		System.out.println("----------------log--------------");
		System.out.println(bs.getRId());
		System.out.println(bs.getAddress());
		System.out.println(bs.getCityofbirth());
		System.out.println(bs.getDateofbirth());
		System.out.println(bs.getName());
		System.out.println(bs.getUname());
	    System.out.println(bs.getEmailed());
		System.out.println(bs.getPassword());
		System.out.println(bs.getPhonenumber());
		System.out.println(bs.getGender());
		
	}catch(Exception e){
		System.out.println("IN CATCH");
		String errorMessage = environment.getProperty(e.getMessage());
		RegisterDetails fb = new RegisterDetails();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<RegisterDetails>(fb,HttpStatus.BAD_REQUEST);

	}
	return responseEntity;
	
}

	
	
	
	

	
	
	
	
	@RequestMapping(method=RequestMethod.POST, value="update")
    public ResponseEntity<RegisterDetails> update(@RequestBody RegisterDetails log) {
		
	Environment environment= ContextFactory.getContext().getEnvironment();
	
	
	service = (UDAIService) ContextFactory.getContext().getBean(UDAIServiceImpl.class);
	
	ResponseEntity<RegisterDetails> responseEntity;
	try{
		
		
		System.out.println("----------------log--------------");
		System.out.println(log.getRId());
		System.out.println(log.getAddress());
		System.out.println(log.getCityofbirth());
		System.out.println(log.getName());
		System.out.println(log.getUname());
	    System.out.println(log.getEmailed());
		System.out.println(log.getPassword());
		System.out.println(log.getPhonenumber());
		System.out.println(log.getGender());
		
		System.out.println("IN try");
		
		System.out.println("************************BEFORE BS************************");
		RegisterDetails bs=service.update(log);
		System.out.println("************************AFTER BS************************");
		
		
		System.out.println("----------------FROM SERVICE--------------");
		System.out.println(bs.getRId());
		System.out.println(bs.getAddress());
		System.out.println(bs.getCityofbirth());
		System.out.println(bs.getName());
		System.out.println(bs.getUname());
	    System.out.println(bs.getEmailed());
		System.out.println(bs.getPassword());
		System.out.println(bs.getPhonenumber());
		System.out.println(bs.getGender());
		
		
		bs.setMessage(environment.getProperty("Service.UPDATESUCCESSFULL"));
		responseEntity = new ResponseEntity<RegisterDetails>(bs,HttpStatus.OK);
		
	}catch(Exception e){
		//System.out.println("IN CATCH");
		System.out.println("ERROR IS : " +e.toString());
		String errorMessage = environment.getProperty(e.getMessage());
		RegisterDetails fb = new RegisterDetails();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<RegisterDetails>(fb,HttpStatus.BAD_REQUEST);

	}
	return responseEntity;
	
}
	
	
	
	
	
	@RequestMapping(method=RequestMethod.POST, value="forgot")
    public ResponseEntity<RegisterDetails> forgotpassword(@RequestBody RegisterDetails log) {
	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (UDAIService) ContextFactory.getContext().getBean(UDAIServiceImpl.class);
	
	ResponseEntity<RegisterDetails> responseEntity;
	try{
		System.out.println("IN try");
		RegisterDetails bs=service.forgotpassword(log.getPhonenumber(),log.getSecurityque(),log.getSecurityans());
		bs.setMessage(environment.getProperty("UDAIApi.fsucccessful"));
		responseEntity = new ResponseEntity<RegisterDetails>(bs,HttpStatus.OK);
		
		System.out.println("----------------log--------------");
		System.out.println(bs.getRId());
		System.out.println(bs.getAddress());
		System.out.println(bs.getCityofbirth());
		System.out.println(bs.getDateofbirth());
		System.out.println(bs.getName());
		System.out.println(bs.getUname());
	    System.out.println(bs.getEmailed());
		System.out.println(bs.getPassword());
		System.out.println(bs.getPhonenumber());
		System.out.println(bs.getGender());
		System.out.println(bs.getSecurityque());
		System.out.println(bs.getSecurityans());
		
		
	}catch(Exception e){
		System.out.println("IN CATCH");
		String errorMessage = environment.getProperty(e.getMessage());
		RegisterDetails fb = new RegisterDetails();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<RegisterDetails>(fb,HttpStatus.BAD_REQUEST);

	}
	return responseEntity;
	
}


	
}
	
	