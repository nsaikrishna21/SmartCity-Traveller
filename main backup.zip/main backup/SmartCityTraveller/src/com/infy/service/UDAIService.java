package com.infy.service;

import com.infy.entity.RegisterDetailsEntity;
import com.infy.model.RegisterDetails;

public interface UDAIService {



	public RegisterDetails add(RegisterDetails addUser) throws Exception;
	public RegisterDetails login(String phoneORuser, String password) throws Exception;
	public RegisterDetails update(RegisterDetails user) throws Exception;
	public RegisterDetails forgotpassword(String phonenumber, String securityque, String securityans) throws Exception;
	
	
}
