package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.infy.dao.UDAIDAOImpl;
import com.infy.entity.RegisterDetailsEntity;
import com.infy.model.RegisterDetails;

@Service("UDAIService")
@Transactional(readOnly = true)
public class UDAIServiceImpl implements UDAIService {

	
	@Autowired
	private UDAIDAOImpl dao;

	



@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public RegisterDetails add(RegisterDetails cust) throws Exception {
	// TODO Auto-generated method stub
	System.out.println("in service");
	RegisterDetails cd=dao.add(cust);

	if(cd==null){
		throw new Exception("Service.INVALID");
	}
	return cd;
}

@Override
@Transactional(readOnly = true)

public RegisterDetails login(String phoneORuser, String password) throws Exception {
	// TODO Auto-generated method stub

	
	RegisterDetails bs = dao.login(phoneORuser,password);
	
	if(bs==null) {
		
		throw new Exception("Service.LOGINUNSUCCESSFUL");
	}
	else{

		return bs;
	}
	

}

@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public RegisterDetails update(RegisterDetails user) throws Exception {
	
	RegisterDetails register=dao.update(user);
	
	return register;
	
}

@Override
@Transactional(readOnly = true)
public RegisterDetails forgotpassword(String phonenumber, String securityque, String securityans) throws Exception {
	RegisterDetails reg=dao.forgotpassword(phonenumber,securityque,securityans);
	if(reg==null) {
		throw new Exception("Service.mismatch");
	}else
	{
		return reg;
	}
}


	
}


